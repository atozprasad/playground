"""
Implementation of Authentication metadata service
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'restructuredtext en'

import six

from com.vmware.vapi.common import message_factory
from com.vmware.vapi.metadata.authentication_provider import (
    Package, Component, Service, Source, ComponentData,
    PackageInfo, OperationInfo, AuthenticationInfo, ComponentInfo,
    ServiceInfo)
from com.vmware.vapi.metadata.authentication.service_provider import Operation
from com.vmware.vapi.metadata.util.maps import get_authentication_maps
from com.vmware.vapi.metadata.util.sources_mixin import SourceMixin
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import ErrorFactory

logger = get_vapi_logger(__name__)
AUTHENTICATION = 'authentication'
SCHEMES = 'schemes'
PACKAGES = 'packages'
SERVICES = 'services'
OPERATIONS = 'operations'
SESSION_AWARE = 'SessionAware'
SESSIONLESS = 'SessionLess'
AUTHENTICATION_SCHEME = 'authenticationScheme'
TYPE = 'type'
SESSION_MANAGER = 'sessionManager'


class OperationImpl(Operation):
    """
    Operations to retrieve information about authentications in a vAPI
    operation.
    <p>
    An operation is said to contain authentication information if authentication
    schemes are specified for this operation in the operation definition file.
    """
    def __init__(self, maps):
        """
        Initialize OperationImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Operation.__init__(self)
        self._maps = maps

    def list(self, service_id):
        """
        Get the IDs of all the vAPI operations in the given service that contain
        authentication information.

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service.
        :rtype: :class:`list` of :class:`str`
        :return: list of operation identifiers.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the service identifier does not exist.
        """
        if service_id not in self._maps.service_info:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.authentication.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return [operation_name
                for svc_name, operation_name in self._maps.operation_info.keys()
                if svc_name == service_id]

    def get(self, service_id, operation_id):
        """
        Get information about a vAPI operation that contains authentication
        information.

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service.
        :type  operation_id: :class:`str`
        :param operation_id: Identifier of the operation.
        :rtype:
            :class:`com.vmware.vapi.metadata.authentication_provider.OperationInfo`  # pylint: disable=line-too-long
        :return: Operation info for the vAPI operation that contains
            authentication information.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the service identifier does not exist.
        """
        operation_info = self._maps.operation_info.get((service_id,
                                                        operation_id))
        if operation_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.authentication.operation.not_found',
                operation_id, service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return operation_info


class PackageImpl(Package):
    """
    Operations to retrieve information about authentications in a vAPI package.

    A Package is said to contain authentication information if there is a
    default authentication assigned to all operations within a package or if
    one of the operations within this package has authentication information.
    """
    def __init__(self, maps):
        """
        Initialize PackageImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Package.__init__(self)
        self._maps = maps

    def list(self):
        """
        List of all vAPI packages that have authentication information.

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified package identifiers.
        """
        return self._maps.package_info.keys()

    def get(self, package_id):
        """
        Get the authentication information for a vAPI package.

        :type  package_id: :class:`str`
        :param package_id: fully qualified package identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.authentication_provider.PackageInfo`  # pylint: disable=line-too-long
        :return: authentication information for the vAPI package.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the package identifier does not exist.
        """
        package_info = self._maps.package_info.get(package_id)
        if package_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.authentication.package.not_found',
                package_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return package_info


class ComponentImpl(Component):
    """
    Operations to retrieve information about the authentications in a vAPI
    component.

    A Component is said to contain authentication information if any of its
    packages contain authentication information.
    """
    def __init__(self, maps):
        """
        Initialize PackageImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Component.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI components.

        :rtype: :class:`list` of :class:`str`
        :return: List of component identifiers.
        """
        return self._maps.component_info.keys()

    def get(self, component_id):
        """
        Get the authentication information of a vAPI component.

        :type  component_id: :class:`str`
        :param component_id: Component identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.authentication_provider.ComponentData`  # pylint: disable=line-too-long
        :return: authentication information of the vAPI component.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the component identifier does not exist.
        """
        component_info = self._maps.component_info.get(component_id)
        if component_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.authentication.component.not_found',
                component_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return ComponentData(
            info=component_info,
            fingerprint=self.fingerprint(component_id=component_id))

    def fingerprint(self, component_id):
        """
        Returns the fingerprint computed from all the metadata
        of a vAPI component present on the server. The fingerprint provides
        clients an efficient way to check if the component metadata has been
        modified on the server. The client can do this by comparing the result
        of this operation with the fingerprint returned in the result of
        {@link com.vmware.vapi.metadata.authentication.Component#get}

        :type  component_id: :class:`str`
        :param component_id: Component identifier.
        :rtype: :class:`str`
        :return: fingerprint of metadata of a vAPI component.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the component identifier does not exist.
        """
        fingerprint = self._maps.component_fingerprints.get(component_id)
        if fingerprint is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.authentication.component.not_found',
                component_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return fingerprint


class ServiceImpl(Service):
    """
    Operations to retrieve information about authentication information of a
    vAPI service.

    A service is said to contain authentication information if there is a
    default authentication assigned to all operations within a service or if
    one of the operations within this service has authentication information.
    """
    def __init__(self, maps):
        """
        Initialize ServiceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Service.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI services that have operations with authentication
        information.

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified service identifiers.
        """
        return self._maps.service_info.keys()

    def get(self, service_id):
        """
        Get the authentication information for a vAPI service.

        :type  service_id: :class:`str`
        :param service_id: fully qualified service identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.authentication_provider.ServiceInfo`  # pylint: disable=line-too-long
        :return: identifier information for the vAPI service.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the service identifier does not exist.
        """
        service_info = self._maps.service_info.get(service_id)
        if service_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.authentication.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return service_info


class SourceImpl(SourceMixin, Source):
    """
    Operations to manage the metadata sources for authentication information
    """
    _types = [SESSIONLESS, SESSION_AWARE]

    def __init__(self, maps, cfg):
        """
        Initialize SourceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        :type  cfg: :class:`dict` of :class:`str` and :class:`str`
        :param cfg: Configuration for the service specified in the properties
            file
        """
        Source.__init__(self)
        SourceMixin.__init__(self, maps, AUTHENTICATION, cfg)

    def _parse_authentication_schemes(self, all_scheme_metadata):
        """
        Parse the authentication schemes sections from the config file

        :type  all_scheme_metadata: :class:`dict`
        :param all_scheme_metadata: ConfigParser object of the
            authentication definition file
        :rtype: :class:`dict`
        :return: A dictionary of Scheme section names and AuthenticationInfo
            objects
        """
        scheme_map = {}

        # Only parse the scheme sections
        for scheme_name in all_scheme_metadata.keys():
            scheme_metadata = all_scheme_metadata.get(scheme_name)
            scheme = scheme_metadata.get(AUTHENTICATION_SCHEME)
            scheme_type = scheme_metadata.get(TYPE)

            # Validate and convert scheme type
            if scheme_type not in self._types:
                msg = message_factory.get_message(
                    'com.vmware.vapi.metadata.authentication.scheme.type.'
                    'invalid',
                     scheme_type)
                logger.info(msg)
                raise ErrorFactory.new_invalid_argument(messages=[msg])
            if scheme_type == SESSION_AWARE:
                scheme_type_value = AuthenticationInfo.SchemeType.SESSION_AWARE
                session_manager = scheme_metadata.get(SESSION_MANAGER)
            else:
                scheme_type_value = AuthenticationInfo.SchemeType.SESSIONLESS
                session_manager = None

            scheme_map[scheme_name] = AuthenticationInfo(
                scheme_type=scheme_type_value,
                scheme=scheme,
                session_manager=session_manager)
        return scheme_map

    @staticmethod
    def _raise_invalid_scheme_error(scheme_name):
        """
        Raise an invalid scheme error

        :type  scheme_name: :class:`str`
        :param scheme_name: Scheme name
        :raise: :class:`com.vmware.vapi.std.errors.InvalidArgument`:
            If the scheme is not present in the config file
        """
        msg = message_factory.get_message(
            'com.vmware.vapi.metadata.authentication.scheme.invalid',
            scheme_name)
        logger.info(msg)
        raise ErrorFactory.new_invalid_argument(messages=[msg])

    def _parse_package_schemes(self, package_metadata, scheme_map):
        """
        Parse schemes defined at package level

        :type  package_metadata: :class:`dict`
        :param package_metadata: Package metadata
        :type  scheme_map: :class:`dict`
        :param scheme_map: Dictionary of authentication schemes defined
        :rtype: :class:`dict`
        :return: Processed package scheme data
        """
        package_map = {}
        for package_name, schemes in six.iteritems(package_metadata):
            try:
                schemes = [scheme_map[scheme] for scheme in schemes]
            except KeyError as err:
                self._raise_invalid_scheme_error(err.args[0])
            package_info = PackageInfo(schemes=schemes,
                                       services={})
            package_map[package_name] = package_info
        return package_map

    def _parse_service_schemes(self, service_metadata, scheme_map):
        """
        Parse schemes defined at service level

        :type  service_metadata: :class:`dict`
        :param service_metadata: Service metadata
        :type  scheme_map: :class:`dict`
        :param scheme_map: Dictionary of authentication schemes defined
        :rtype: :class:`dict`
        :return: Processed service scheme data
        """
        service_map = {}
        for service_name, schemes in six.iteritems(service_metadata):
            try:
                schemes = [scheme_map[scheme] for scheme in schemes]
            except KeyError as err:
                self._raise_invalid_scheme_error(err.args[0])
            service_info = ServiceInfo(schemes=schemes,
                                       operations={})
            service_map[service_name] = service_info
        return service_map

    def _parse_operation_schemes(self, operation_metadata, scheme_map):
        """
        Parse schemes defined at operation level

        :type  operation_metadata: :class:`dict`
        :param operation_metadata: Operation metadata
        :type  scheme_map: :class:`dict`
        :param scheme_map: Dictionary of authentication schemes defined
        :rtype: :class:`dict`
        :return: Processed operation scheme data
        """
        operation_map = {}
        for operation_name, schemes in six.iteritems(operation_metadata):
            try:
                schemes = [scheme_map[scheme] for scheme in schemes]
            except KeyError as err:
                self._raise_invalid_scheme_error(err.args[0])
            operation_info = OperationInfo(schemes=schemes)
            operation_map[operation_name] = operation_info
        return operation_map

    def _parse_json_component_info(self, id_, component_metadata):
        """
        Parse authentication metadata from the config file

        :type  id_: :class:`str`
        :param id_: Source identifier
        :type  component_metadata: :class:`dict`
        :param component_metadata: ConfigParser object of the
            authentication definition file
        :rtype:
            :class:`com.vmware.vapi.metadata.authentication_provider.ComponentInfo`  # pylint: disable=line-too-long
        :return: ComponentInfo object
        """
        scheme_metadata = component_metadata.get(SCHEMES, {})
        scheme_map = self._parse_authentication_schemes(scheme_metadata)

        # Process package specific schemes
        package_metadata = component_metadata.get(PACKAGES, {})
        package_map = self._parse_package_schemes(package_metadata, scheme_map)

        # Process service specific schemes
        service_metadata = component_metadata.get(SERVICES, {})
        service_map = self._parse_service_schemes(service_metadata, scheme_map)

        # Process operation specific schemes
        operation_metadata = component_metadata.get(OPERATIONS, {})
        operation_map = self._parse_operation_schemes(operation_metadata,
                                                      scheme_map)

        # Merge operation data into service data
        for operation_full_name, operation_info in six.iteritems(operation_map):
            tokens = operation_full_name.split('.')
            service_name = '.'.join(tokens[:-1])
            operation_name = tokens[-1]
            service_info = service_map.get(service_name,
                                           ServiceInfo(schemes=[],
                                                       operations={}))
            service_info.operations[operation_name] = operation_info
            self._maps.operation_info[(service_name,
                                       operation_name)] = operation_info
            self._maps.operation_mapping.setdefault(id_, []).append(
                (service_name, operation_name))
            service_map[service_name] = service_info

        # Merge service data into package data
        for service_name, service_info in six.iteritems(service_map):
            tokens = service_name.split('.')
            package_name = '.'.join(tokens[:-1])
            package_info = package_map.get(package_name,
                                           PackageInfo(schemes=[],
                                                       services={}))
            package_info.services[service_name] = service_info
            self._maps.service_info[service_name] = service_info
            self._maps.service_mapping.setdefault(id_, []).append(service_name)
            package_map[package_name] = package_info

        # Create component info
        component_info = ComponentInfo(packages={})
        for k, v in six.iteritems(package_map):
            self._maps.package_info[k] = v
            self._maps.package_mapping.setdefault(id_, []).append(k)
            component_info.packages[k] = v
        return component_info

    def _parse_json_metadata(self, source_id, idl_metadata):
        """
        Parse metadata obtained from a file

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  idl_metadata: :class:`list` of :class:`dict`
        :param idl_metadata: metamodel metadata
        """
        if not idl_metadata:
            return

        component_data = idl_metadata.get('component')
        if not component_data:
            # Backward compatibility
            component_data = idl_metadata.get('product')
        component_name = component_data.get('name')

        component_info = self._parse_json_component_info(source_id,
                                                         component_data)
        self._maps.component_info[component_name] = component_info

        self._maps.component_mapping.setdefault(source_id,
                                                []).append(component_name)

        fingerprint = self._generate_fingerprint(component_info)
        self._maps.component_fingerprints[component_name] = fingerprint

    def _parse_remote_service_info(self, source_id, service_name, service_info):
        """
        Parse ServiceInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  service_name: :class:`str`
        :param service_name: Service Name
        :type  service_info:
            :class:`com.vmware.vapi.metadata.authentication_provider.ServiceInfo`  # pylint: disable=line-too-long
        :param service_info: ServiceInfo object
        """
        for name, info in six.iteritems(service_info.operations):
            self._maps.operation_info[(service_name, name)] = info
            self._maps.operation_mapping.setdefault(source_id, []).append(
                (service_name, name))

    def _parse_remote_package_info(self, source_id, package_info):
        """
        Parse PackageInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  package_info:
            :class:`com.vmware.vapi.metadata.authentication_provider.PackageInfo`  # pylint: disable=line-too-long
        :param package_info: PackageInfo object
        """
        for name, info in six.iteritems(package_info.services):
            self._parse_remote_service_info(source_id, name, info)
            self._maps.service_info[name] = info
            self._maps.service_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_component_info(self, source_id, component_info):
        """
        Parse ComponentInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  component_info:
            :class:`com.vmware.vapi.metadata.authentication_provider.ComponentInfo`  # pylint: disable=line-too-long
        :param component_info: ComponentInfo object
        """
        for name, info in six.iteritems(component_info.packages):
            self._parse_remote_package_info(source_id, info)
            self._maps.package_info[name] = info
            self._maps.package_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_metadata(self, source_id, stub_factory):
        """
        Parse metadata obtained from a remote source

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  stub_factory: :class:`vmware.vapi.bindings.stub.StubFactory`
        :param stub_factory: Stub factory
        """
        if not stub_factory:
            return
        component_stub = stub_factory.create_stub(
            'com.vmware.vapi.metadata.authentication.component')
        for component_id in component_stub.list():
            component_data = component_stub.get(component_id=component_id)
            self._parse_remote_component_info(source_id, component_data.info)
            self._maps.component_info[component_id] = component_data.info

            self._maps.component_mapping.setdefault(source_id,
                                                    []).append(component_id)
            self._maps.component_fingerprints[component_id] = \
                component_data.fingerprint


def register_instance(cfg):
    """
    Specify the instances that should be
    registered with the api provider

    :type  cfg: :class:`dict` of :class:`str` and :class:`str`
    :param cfg: Configuration for the service specified in the properties file
    """
    maps = get_authentication_maps()
    return [
        OperationImpl(maps),
        PackageImpl(maps),
        ComponentImpl(maps),
        ServiceImpl(maps),
        SourceImpl(maps, cfg),
    ]
