"""
CLI metadata command service
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'epytext en'

import six

from .maps import get_shared_cli_maps

from com.vmware.vapi.common import message_factory
from com.vmware.vapi.metadata.cli_provider import Command
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import ErrorFactory

logger = get_vapi_logger(__name__)


class CommandImpl(Command):
    """
    Operations to get details of CLI command nodes
    """
    def __init__(self, maps):
        Command.__init__(self)
        self._maps = maps

    def list(self, **kwargs):
        """
        Get a list of all commands in the CLI node tree or given namespace

        :type  path: :class:`str`
        :kwarg path: Path of the namespace node

        :rtype: :class:`list` of
            :class:`com.vmware.vapi.metadata.cli_provider.Command.Identity`
        :return: Command list
        """

        path = kwargs.get('path')

        if path is None:
            ids = [value[1].identity
                   for key, values in six.iteritems(self._maps.command_info)
                   if key.rsplit('#')[-1] == 'command'
                   for value in values]
        else:
            ids = [value[1].identity
                   for key, values in six.iteritems(self._maps.command_info)
                   if key.rsplit('#')[-1] == 'command'
                   and key.split('#')[0] == path
                   for value in values]
            if not ids:
                msg = message_factory.get_message(
                        'com.vmware.vapi.metadata.cli.not_found',
                        path)
                logger.error(msg)
                raise ErrorFactory.new_not_found(messages=[msg])
        return list(set(ids))

    def get(self, **kwargs):
        """
        Get information about how to execute a specific command

        :type  identity:
            :class:`com.vmware.vapi.metadata.cli_provider.Command.Identity`
        :kwarg identity: Path and name of the command.

        :rtype: :class:`com.vmware.vapi.metadata.cli_provider.Command.Info`
        :return: Command Info
        """

        identity = kwargs.get('identity')

        key = '%s#%s#%s' % (identity.path, identity.name, 'command')

        if key in self._maps.command_info:
            values = [val for _, val in self._maps.command_info[key]]
            return values[0]
        else:
            msg = message_factory.get_message(
                    'com.vmware.vapi.metadata.cli.not_found',
                    key)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return self._maps.command_info.get(key)

    def fingerprint(self):
        """
        Fingerprint of all metadata on the server

        :rtype: :class:`str`
        :return: Fingerprint of metadata present in the server
        """
        return self._maps.command_fingerprint


def register_instance():
    """
    Specify the instances that should be
    registered with the api provider
    """
    return [CommandImpl(get_shared_cli_maps())]
